import os
import json
import re
import time
from typing import List, Dict, Any, Optional
from langchain_google_genai import ChatGoogleGenerativeAI
from src.reference_extractor import extract_references_from_document

RELATION_PROMPT = """Lê este artigo jurídico e identifica todas as referências ou citações a outros artigos ou leis (pode ser o próprio Código ou outros códigos/leis).
Identifica o tipo de relação:
- "altera": se o artigo atual altera a outra lei/artigo
- "revoga": se o artigo atual revoga a outra lei/artigo
- "remete": se o artigo atual remete ou diz "aplica-se o artigo X"
- "cita": se apenas menciona

Devolve APENAS um JSON válido no seguinte formato, sem formatação markdown (como ```json), sem texto adicional e sem comentários:
{{
  "references": [
    {{
      "target_document": "codigo_civil" ou "codigo_trabalho" ou "outro",
      "target_article": "número do artigo referenciado ou null",
      "relation_type": "altera" ou "revoga" ou "remete" ou "cita",
      "raw_reference": "o texto exato da referência"
    }}
  ]
}}

Documento atual: {doc_title}
Artigo atual: Artigo {art_num}.º - {art_title}
Texto do artigo:
{art_text}

JSON:"""

# Models to try in order (fallback chain)
LLM_MODELS = ["gemini-2.0-flash", "gemini-flash-latest", "gemini-2.5-flash", "gemini-3.5-flash", "gemini-1.5-flash", "gemini-pro"]

# Global cache of API check results to avoid repeating calls on every document
_API_CHECKED = False
_API_WORKING = False
_WORKING_MODEL_IDX = 0

def extract_relations_with_llm(
    doc: Dict[str, Any],
    google_api_key: Optional[str] = None,
    max_llm_articles: int = 15
) -> List[Dict[str, Any]]:
    """
    Extract relationships using Gemini LLM. Fallbacks to Regex if LLM fails or API key is missing.
    """
    global _API_CHECKED, _API_WORKING, _WORKING_MODEL_IDX
    
    api_key = google_api_key or os.getenv("GOOGLE_API_KEY", "")
    
    if not api_key:
        print(f"⚠️ No Google API Key found. Using Regex fallback for {doc['document_id']}.")
        return extract_references_from_document(doc)
        
    extracted_relations = []
    doc_id = doc["document_id"]
    doc_title = doc.get("title", doc_id)
    
    # Track current model index
    model_idx = 0
    llm = None
    
    def get_llm(idx):
        if idx >= len(LLM_MODELS):
            return None
        try:
            return ChatGoogleGenerativeAI(
                model=LLM_MODELS[idx],
                temperature=0.0,
                google_api_key=api_key,
                max_retries=0 # Disable slow retries to fail fast
            )
        except Exception as e:
            print(f"⚠️ Failed to init {LLM_MODELS[idx]}: {e}")
            return None

    # Use cached check result if already tested
    if _API_CHECKED:
        if not _API_WORKING:
            return extract_references_from_document(doc)
        else:
            model_idx = _WORKING_MODEL_IDX
            llm = get_llm(model_idx)
    else:
        # Test the connection to the model beforehand once
        print(f"🔌 Testing Gemini model {LLM_MODELS[model_idx]} connectivity (once)...")
        conn_ok = False
        while model_idx < len(LLM_MODELS):
            llm = get_llm(model_idx)
            if not llm:
                model_idx += 1
                continue
            try:
                # Perform a quick 1-second verify test call
                llm.invoke("Hi")
                conn_ok = True
                _API_WORKING = True
                _WORKING_MODEL_IDX = model_idx
                print(f"✅ Successful connection established with model: {LLM_MODELS[model_idx]}")
                break
            except Exception as e:
                print(f"⚠️ Connection check failed for model {LLM_MODELS[model_idx]}: {e}")
                model_idx += 1
                llm = None
                
        _API_CHECKED = True
        if not conn_ok or not llm:
            _API_WORKING = False
            print("⚠️ All Gemini models failed check. Using Regex fallback for all documents instantly.")
            return extract_references_from_document(doc)
        
    for idx, art in enumerate(doc.get("articles", [])):
        art_num = art.get("number", "")
        art_title = art.get("title", "")
        art_text = art.get("text", "")
        
        if not art_text.strip():
            continue
            
        # Fast-fallback to regex once max_llm_articles limit is hit
        if idx >= max_llm_articles:
            single_art_doc = {
                "document_id": doc_id,
                "articles": [art]
            }
            extracted_relations.extend(extract_references_from_document(single_art_doc))
            continue
            
        prompt = RELATION_PROMPT.format(
            doc_title=doc_title,
            art_num=art_num,
            art_title=art_title,
            art_text=art_text
        )
        
        success = False
        # Small sleep to respect RPM limits
        time.sleep(0.6)
        
        while not success and model_idx < len(LLM_MODELS):
            try:
                if not llm:
                    llm = get_llm(model_idx)
                if not llm:
                    break
                    
                response = llm.invoke(prompt)
                raw_content = response.content.strip()
                
                if raw_content.startswith("```"):
                    raw_content = re.sub(r"^```(?:json)?\n", "", raw_content)
                    raw_content = re.sub(r"\n```$", "", raw_content)
                raw_content = raw_content.strip()
                
                data = json.loads(raw_content)
                
                for ref in data.get("references", []):
                    target_doc = ref.get("target_document")
                    target_art = ref.get("target_article")
                    rel_type = ref.get("relation_type", "cita")
                    raw_ref = ref.get("raw_reference", "")
                    
                    extracted_relations.append({
                        "source_document": doc_id,
                        "source_article": art_num,
                        "target_document": target_doc if target_doc else "desconhecido",
                        "target_article": target_art,
                        "edge_type": rel_type,
                        "raw_text": raw_ref
                    })
                success = True
                
            except Exception as e:
                print(f"⚠️ LLM Error with {LLM_MODELS[model_idx]} for Artigo {art_num}: {e}")
                # Try next model
                model_idx += 1
                llm = None
                if model_idx >= len(LLM_MODELS):
                    break
                print(f"🔄 Switching to fallback model: {LLM_MODELS[model_idx]}")
                time.sleep(1.0)
                
        if not success:
            print(f"⚠️ All LLM options failed for Artigo {art_num} of {doc_id}. Falling back to Regex for this article.")
            single_art_doc = {
                "document_id": doc_id,
                "articles": [art]
            }
            extracted_relations.extend(extract_references_from_document(single_art_doc))
            
    return extracted_relations
