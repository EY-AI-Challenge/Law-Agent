"""
TXT Parser Module
Parses legal text files structured with 'Artigo X.º' markers into
article-level chunks suitable for the graph and RAG pipelines.
"""

import re
import os
from typing import List, Dict, Any


def parse_txt_file(file_path: str, doc_id: str = "", title: str = "") -> Dict[str, Any]:
    """
    Parse a single legal text file and segment it into articles.

    Expected format (one or more articles):
        Artigo X.º
        Title of article
        Body text...
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Auto-detect doc_id from filename if not provided
    if not doc_id:
        doc_id = os.path.splitext(os.path.basename(file_path))[0]

    # Auto-detect title from first line (if it starts with #)
    if not title:
        first_line = content.split("\n")[0].strip()
        if first_line.startswith("#"):
            title = first_line.lstrip("# ").strip()
        else:
            title = doc_id.replace("_", " ").title()

    # Detect document type
    doc_type = _detect_doc_type(doc_id, title)

    # Segment into articles
    pattern = r"(?:^|\n)Artigo\s+(\d+)\.º\s*\n"
    matches = list(re.finditer(pattern, content))

    articles = []
    seen = set()
    for i, match in enumerate(matches):
        art_num = match.group(1)

        # Skip duplicates
        if art_num in seen:
            continue
        seen.add(art_num)

        start_idx = match.end()
        end_idx = matches[i + 1].start() if i + 1 < len(matches) else len(content)

        art_block = content[start_idx:end_idx].strip()
        lines = art_block.split("\n")
        art_title = lines[0].strip() if lines else ""
        art_text = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""

        if len(art_text) < 10:
            continue

        articles.append({
            "number": art_num,
            "title": art_title,
            "text": art_text,
        })

    return {
        "document_id": doc_id,
        "type": doc_type,
        "title": title,
        "num_articles": len(articles),
        "articles": articles,
    }


def _detect_doc_type(doc_id: str, title: str) -> str:
    """Guess the document type from its ID or title."""
    combined = (doc_id + " " + title).lower()

    if "codigo_trabalho" in combined or "código do trabalho" in combined:
        return "codigo_trabalho"
    if "codigo_civil" in combined or "código civil" in combined:
        return "codigo_civil"
    if "decreto" in combined:
        return "decreto_lei"
    if "portaria" in combined:
        return "portaria"
    if "lei" in combined:
        return "lei"
    if "regulament" in combined:
        return "regulamento"
    if "constituicao" in combined or "constituição" in combined:
        return "constituicao"
    return "unknown"


def parse_all_txts(data_dir: str) -> List[Dict[str, Any]]:
    """
    Parse every .txt file in data_dir that contains at least one
    'Artigo X.º' marker, returning a list of document dicts.
    """
    docs = []

    if not os.path.isdir(data_dir):
        print(f"⚠️ Diretório '{data_dir}' não existe.")
        return docs

    txt_files = sorted(f for f in os.listdir(data_dir) if f.endswith(".txt"))
    if not txt_files:
        print(f"⚠️ Nenhum ficheiro .txt encontrado em '{data_dir}'.")
        return docs

    for filename in txt_files:
        file_path = os.path.join(data_dir, filename)
        try:
            doc_data = parse_txt_file(file_path)
            if doc_data["num_articles"] > 0:
                docs.append(doc_data)
                print(f"  ✅ {filename}: {doc_data['num_articles']} artigos ({doc_data['type']})")
            else:
                print(f"  ⚠️ {filename}: nenhum artigo encontrado — ignorado.")
        except Exception as e:
            print(f"  ❌ Erro em {filename}: {e}")

    print(f"\n📊 Total: {len(docs)} documentos, {sum(d['num_articles'] for d in docs)} artigos")
    return docs
