"""
Scraper para o Diário da República Eletrónico (DRE)
Extrai legislação consolidada dos temas "Trabalho" e "Civil"
usando Playwright para renderizar o OutSystems SPA.

Inclui delay entre pedidos e retry com backoff para evitar bloqueios.
"""

import re
import os
import time
import json
from typing import Optional, List, Dict
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

# ─── Config ────────────────────────────────────────────────────────────────────
TEMA_URL = "https://diariodarepublica.pt/dr/legislacao-por-tema"
REQUEST_DELAY = 4  # seconds between page loads to avoid rate limiting
MAX_RETRIES = 2

UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)


# ─── Helpers ───────────────────────────────────────────────────────────────────

def _clean_text(text: str) -> str:
    """Remove excessive whitespace and normalise blank lines."""
    lines = [l.rstrip() for l in text.splitlines()]
    cleaned, prev_blank = [], False
    for line in lines:
        if not line.strip():
            if not prev_blank:
                cleaned.append("")
            prev_blank = True
        else:
            cleaned.append(line)
            prev_blank = False
    return "\n".join(cleaned).strip()


def _extract_articles(raw_text: str) -> List[dict]:
    """Segment raw text into articles via regex."""
    normalised = re.sub(r"Artigo\s+(\d+)\s*[.°º]?\s*[º°]?", r"Artigo \1.º", raw_text)

    matches = list(re.finditer(
        r"Artigo\s+(\d+)\.º\s*\n?([^\n]{0,150})\n([\s\S]*?)(?=Artigo\s+\d+\.º|$)",
        normalised,
    ))

    articles = []
    seen = set()
    for m in matches:
        num = m.group(1).strip()
        title = m.group(2).strip().rstrip(".")
        body = _clean_text(m.group(3))

        if num in seen or len(body) < 15:
            continue
        seen.add(num)

        # Remove DRE UI noise
        for pat in [
            r"Alterações ao artigo.*", r"Alterado pelo/a.*",
            r"Aditado pelo/a.*", r"Revogado pelo/a.*",
            r"^Alertas$", r"^Versão em vigor.*",
        ]:
            body = re.sub(pat, "", body, flags=re.MULTILINE).strip()

        body = _clean_text(body)
        if len(body) < 15:
            continue

        articles.append({"number": num, "title": title, "text": body})

    return articles


def _doc_id_from_text(text: str) -> str:
    """Derive a filesystem-friendly doc ID from the law title text."""
    text = text.lower()
    text = re.sub(r"\s*-\s*diário.*$", "", text)  # remove DR reference
    text = re.sub(r"[^\w\s]", "", text)  # Remove / and other special characters
    text = re.sub(r"\s+", "_", text.strip())
    return text[:60]


def _safe_goto(page, url: str, retries: int = MAX_RETRIES) -> bool:
    """Navigate to URL with retry logic."""
    for attempt in range(retries + 1):
        try:
            page.goto(url, timeout=30000, wait_until="domcontentloaded")
            return True
        except Exception as e:
            if attempt < retries:
                wait = REQUEST_DELAY * (attempt + 2)
                print(f"    ⏳ Retry {attempt+1}/{retries} em {wait}s...")
                time.sleep(wait)
            else:
                raise e
    return False


# ─── Core Scraping ─────────────────────────────────────────────────────────────

def discover_law_links(page, theme_name: str) -> List[dict]:
    """Click a theme and collect all consolidated-law links."""
    try:
        _safe_goto(page, TEMA_URL)
    except Exception as e:
        print(f"  ❌ Não consegui aceder a {TEMA_URL}: {e}")
        return []

    time.sleep(5)

    try:
        # Click the exact link in the theme list to avoid clicking header/footer links
        theme_selector = f"//div[contains(@class, 'theme') or contains(@class, 'tema') or @id='content']//a[normalize-space(text())='{theme_name}']"
        if page.locator(theme_selector).count() > 0:
            page.click(theme_selector)
        else:
            # Fallback
            page.click(f"text={theme_name}", timeout=8000)
    except PlaywrightTimeout:
        print(f"  ⚠️ Não foi possível clicar no tema '{theme_name}'.")
        return []

    time.sleep(5)

    links = page.evaluate("""() => {
        return Array.from(document.querySelectorAll('a'))
            .map(a => ({ href: a.href, text: a.innerText.trim().slice(0, 200) }))
            .filter(l => l.href.includes('legislacao-consolidada'))
    }""")

    for l in links:
        l["theme"] = theme_name

    return links


def scrape_consolidated_page(page, url: str, max_scroll: int = 25) -> str:
    """Navigate to a consolidated-law page and return the body text."""
    _safe_goto(page, url)
    time.sleep(3)

    # Accept cookies
    try:
        btn = page.locator("button:has-text('Aceitar'), button:has-text('Accept')")
        if btn.count() > 0:
            btn.first.click()
            time.sleep(1)
    except Exception:
        pass

    # Scroll to load lazy content
    for _ in range(max_scroll):
        page.keyboard.press("End")
        time.sleep(0.3)
    time.sleep(2)

    return page.inner_text("body")


# ─── Public API ────────────────────────────────────────────────────────────────

def scrape_all(
    output_dir: str = "data",
    headless: bool = True,
    max_articles_per_doc: int = 0,
    themes: Optional[List[str]] = None,
    progress_callback=None,
) -> dict:
    """
    Scrape all consolidated laws for the requested themes from DRE.

    Returns dict mapping theme -> list of { doc_id, title, num_articles, file_path }
    """
    os.makedirs(output_dir, exist_ok=True)
    themes = themes or ["Trabalho", "Civil"]
    results = {}

    def _log(msg):
        print(msg)
        if progress_callback:
            progress_callback(msg)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent=UA, locale="pt-PT",
        )
        page = context.new_page()

        for theme in themes:
            _log(f"\n{'='*60}")
            _log(f"📂 Tema: {theme}")
            _log(f"{'='*60}")

            law_links = discover_law_links(page, theme)
            _log(f"  📋 {len(law_links)} leis encontradas")

            theme_results = []

            for i, link in enumerate(law_links, 1):
                url = link["href"]
                title_text = link["text"]
                doc_id = _doc_id_from_text(title_text)
                file_path = os.path.join(output_dir, f"{doc_id}.txt")

                # Skip if already scraped
                if os.path.exists(file_path) and os.path.getsize(file_path) > 100:
                    _log(f"  [{i}/{len(law_links)}] ⏭ Já existe: {doc_id}")
                    # Still count it
                    existing = _extract_articles(open(file_path, "r", encoding="utf-8").read())
                    if existing:
                        theme_results.append({
                            "doc_id": doc_id, "title": title_text,
                            "num_articles": len(existing), "file_path": file_path,
                        })
                    continue

                _log(f"  [{i}/{len(law_links)}] {title_text[:70]}...")

                # Rate-limit delay
                time.sleep(REQUEST_DELAY)

                try:
                    raw = scrape_consolidated_page(page, url)
                    articles = _extract_articles(raw)

                    if max_articles_per_doc > 0:
                        articles = articles[:max_articles_per_doc]

                    if not articles:
                        _log(f"    ⚠️ 0 artigos — ignorado.")
                        continue

                    # Save
                    out_lines = [f"# {title_text}\n"]
                    for art in articles:
                        out_lines.append(f"Artigo {art['number']}.º")
                        out_lines.append(art["title"])
                        out_lines.append(art["text"])
                        out_lines.append("")

                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write("\n".join(out_lines))

                    _log(f"    ✅ {len(articles)} artigos → {doc_id}.txt")
                    theme_results.append({
                        "doc_id": doc_id, "title": title_text,
                        "num_articles": len(articles), "file_path": file_path,
                    })

                except Exception as e:
                    _log(f"    ❌ Erro: {str(e)[:100]}")

            results[theme] = theme_results

        context.close()
        browser.close()

    return results


# ─── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="🏛️ Scraper DRE")
    parser.add_argument("--output-dir", default="data")
    parser.add_argument("--visible", action="store_true")
    parser.add_argument("--max-articles", type=int, default=0)
    parser.add_argument("--themes", nargs="+", default=None)
    args = parser.parse_args()

    print("🏛️  Diário da República — Scraper Playwright")
    print("=" * 60)

    results = scrape_all(
        output_dir=args.output_dir,
        headless=not args.visible,
        max_articles_per_doc=args.max_articles,
        themes=args.themes,
    )

    print("\n" + "=" * 60)
    print("✅ Scraping concluído!\n")
    total = 0
    for theme, docs in results.items():
        print(f"  📂 {theme}: {len(docs)} documentos")
        for d in docs:
            print(f"     • {d['title'][:60]}  ({d['num_articles']} artigos)")
            total += d["num_articles"]
    print(f"\n  Total: {total} artigos extraídos.")
