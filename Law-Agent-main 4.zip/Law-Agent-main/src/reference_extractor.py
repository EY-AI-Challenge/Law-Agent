"""
Reference Extractor Module
Extracts legal references and citations from Portuguese legal text.
"""

import re
from typing import Optional


# ─── Reference Patterns for Portuguese Legal Documents ───

REFERENCE_PATTERNS = {
    "lei": re.compile(r"Lei\s+n\.?º?\s*(\d+(?:/\d{4})?)", re.IGNORECASE),
    "decreto_lei": re.compile(r"Decreto[- ]Lei\s+n\.?º?\s*(\d+(?:/\d{4})?)", re.IGNORECASE),
    "artigo": re.compile(r"[Aa]rtigo\s+(\d+)\.º(?:-([A-Z]))?"),
    "numero_artigo": re.compile(r"n\.º\s*(\d+)\s+do\s+artigo\s+(\d+)\.º", re.IGNORECASE),
    "alinea": re.compile(r"alínea\s+([a-z])\)\s*(?:do\s+(?:n\.º\s*\d+\s+do\s+)?artigo\s+(\d+)\.º)?", re.IGNORECASE),
    "codigo": re.compile(r"Código\s+(Civil|do\s+Trabalho|Penal|Comercial|de\s+Processo\s+Civil|de\s+Processo\s+Penal)", re.IGNORECASE),
    "portaria": re.compile(r"Portaria\s+n\.?º?\s*(\d+(?:/\d{4})?)", re.IGNORECASE),
    "regulamento": re.compile(r"Regulamento\s+n\.?º?\s*(\d+(?:/\d{4})?)", re.IGNORECASE),
    "diretiva": re.compile(r"Diretiva\s+(?:n\.?º?\s*)?(\d{4}/\d+/(?:UE|CE|CEE))", re.IGNORECASE),
    "constituicao": re.compile(r"Constituição\s+(?:da\s+)?República\s+Portuguesa", re.IGNORECASE),
}

ACTION_PATTERNS = {
    "revoga": re.compile(r"revogad[oa]|é\s+revogad[oa]|ficam?\s+revogad[oa]s?", re.IGNORECASE),
    "altera": re.compile(r"alterad[oa]|procede\s+à\s+alteração|é\s+alterad[oa]", re.IGNORECASE),
    "regulamenta": re.compile(r"regulamenta|regulamentação", re.IGNORECASE),
    "transpoe": re.compile(r"transpõe|transposição", re.IGNORECASE),
    "remete": re.compile(r"nos\s+termos|de\s+acordo\s+com|previsto\s+n[oa]|conforme", re.IGNORECASE),
    "republica": re.compile(r"republicad[oa]|republicação", re.IGNORECASE),
}


class Reference:
    """Represents a legal reference found in text."""

    def __init__(self, ref_type, ref_value, ref_normalized, context, position,
                 action="cita", source_doc=None, source_article=None):
        self.ref_type = ref_type
        self.ref_value = ref_value
        self.ref_normalized = ref_normalized
        self.context = context
        self.position = position
        self.action = action
        self.source_doc = source_doc
        self.source_article = source_article

    def to_dict(self) -> dict:
        return {
            "ref_type": self.ref_type, "ref_value": self.ref_value,
            "ref_normalized": self.ref_normalized, "context": self.context,
            "position": self.position, "action": self.action,
            "source_doc": self.source_doc, "source_article": self.source_article,
        }

    def __repr__(self):
        return f"Reference({self.ref_type}: {self.ref_normalized}, action={self.action})"


def normalize_reference(ref_type: str, ref_value: str) -> str:
    """Normalize a reference to a canonical form."""
    value = ref_value.strip()
    norm_map = {
        "lei": f"Lei n.º {value}", "decreto_lei": f"Decreto-Lei n.º {value}",
        "artigo": f"Artigo {value}.º", "codigo": f"Código {value.title()}",
        "portaria": f"Portaria n.º {value}", "regulamento": f"Regulamento n.º {value}",
        "diretiva": f"Diretiva {value}", "constituicao": "Constituição da República Portuguesa",
    }
    return norm_map.get(ref_type, value)


def detect_action(text: str, ref_position: int, window: int = 200) -> str:
    """Detect the type of legal action around a reference."""
    start = max(0, ref_position - window)
    end = min(len(text), ref_position + window)
    context = text[start:end]
    for action, pattern in ACTION_PATTERNS.items():
        if pattern.search(context):
            return action
    return "cita"


def get_context(text: str, position: int, window: int = 150) -> str:
    """Extract context around a reference position."""
    start = max(0, position - window)
    end = min(len(text), position + window)
    return f"...{text[start:end].replace(chr(10), ' ').strip()}..."


def extract_references(text, source_doc=None, source_article=None) -> list:
    """Extract all legal references from a text string."""
    references = []
    seen = set()

    for ref_type, pattern in REFERENCE_PATTERNS.items():
        for match in pattern.finditer(text):
            position = match.start()

            if ref_type == "constituicao":
                ref_value = "CRP"
            elif ref_type == "numero_artigo":
                ref_value = f"n.º {match.group(1)} do artigo {match.group(2)}.º"
            elif ref_type == "alinea":
                alinea = match.group(1)
                artigo = match.group(2) if match.group(2) else ""
                ref_value = f"alínea {alinea})" + (f" do artigo {artigo}.º" if artigo else "")
            elif ref_type == "artigo":
                ref_value = match.group(1)
                if match.group(2):
                    ref_value += f"-{match.group(2)}"
            else:
                ref_value = match.group(1) if match.groups() else match.group(0)

            ref_normalized = normalize_reference(ref_type, ref_value)
            dedup_key = (ref_type, ref_normalized, position // 100)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)

            references.append(Reference(
                ref_type=ref_type, ref_value=ref_value,
                ref_normalized=ref_normalized,
                context=get_context(text, position),
                position=position, action=detect_action(text, position),
                source_doc=source_doc, source_article=source_article,
            ))

    references.sort(key=lambda r: r.position)
    return references


def extract_references_from_document(document: dict) -> list:
    """Extract all references from a parsed document."""
    all_refs = []
    doc_id = document["document_id"]
    for article in document.get("articles", []):
        refs = extract_references(
            text=article.get("text", ""),
            source_doc=doc_id,
            source_article=article.get("number", "0"),
        )
        all_refs.extend(refs)
    return all_refs


def get_reference_summary(references: list) -> dict:
    """Generate a summary of extracted references."""
    summary = {"total": len(references), "by_type": {}, "by_action": {}, "unique_targets": set()}
    for ref in references:
        summary["by_type"][ref.ref_type] = summary["by_type"].get(ref.ref_type, 0) + 1
        summary["by_action"][ref.action] = summary["by_action"].get(ref.action, 0) + 1
        summary["unique_targets"].add(ref.ref_normalized)
    summary["unique_targets"] = len(summary["unique_targets"])
    return summary


if __name__ == "__main__":
    sample = """
    A presente lei procede à alteração do Código do Trabalho, aprovado pela Lei n.º 7/2009,
    nos termos do artigo 12.º do Código Civil.
    O Decreto-Lei n.º 47344/1966 estabelece as disposições gerais.
    A alínea a) do n.º 2 do artigo 394.º é revogada pela presente lei.
    """
    refs = extract_references(sample, source_doc="sample", source_article="1")
    print(f"Found {len(refs)} references:")
    for ref in refs:
        print(f"  [{ref.ref_type}] {ref.ref_normalized} (action: {ref.action})")
