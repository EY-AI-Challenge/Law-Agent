"""
Graph Builder Module
Constructs and analyzes a graph of relationships between Portuguese legal documents.
Uses NetworkX for graph operations and Pyvis for interactive visualization.
"""

import json
from pathlib import Path
from typing import Optional

import networkx as nx

try:
    from community import community_louvain
except ImportError:
    community_louvain = None

from src.reference_extractor import extract_references_from_document, Reference


# ─── Color Schemes ───

DOC_TYPE_COLORS = {
    "codigo_trabalho": "#FF6B6B",
    "codigo_civil": "#4ECDC4",
    "decreto_lei": "#45B7D1",
    "lei": "#96CEB4",
    "portaria": "#FFEAA7",
    "regulamento": "#DDA0DD",
    "constituicao": "#FFD700",
    "unknown": "#95A5A6",
}

ACTION_COLORS = {
    "cita": "#3498DB",
    "revoga": "#E74C3C",
    "altera": "#F39C12",
    "regulamenta": "#2ECC71",
    "transpoe": "#9B59B6",
    "remete": "#1ABC9C",
    "republica": "#E67E22",
}


def build_graph(documents: list, references: Optional[list] = None) -> nx.DiGraph:
    """
    Build a directed graph from parsed documents and their references.

    Args:
        documents: List of parsed document dicts (from pdf_parser)
        references: Optional pre-extracted references. If None, extracts from documents.

    Returns:
        NetworkX DiGraph with documents/articles as nodes and references as edges
    """
    G = nx.DiGraph()

    # ─── Add Document Nodes ───
    for doc in documents:
        doc_id = doc["document_id"]
        doc_type = doc.get("type", "unknown")

        # Add document-level node
        G.add_node(doc_id, **{
            "label": doc.get("title", doc_id)[:60],
            "node_type": "document",
            "doc_type": doc_type,
            "color": DOC_TYPE_COLORS.get(doc_type, DOC_TYPE_COLORS["unknown"]),
            "size": 30,
            "num_articles": doc.get("num_articles", 0),
            "title_full": doc.get("title", ""),
        })

        # Add article-level nodes
        for article in doc.get("articles", []):
            art_num = article.get("number", "0")
            art_id = f"{doc_id}_art{art_num}"

            G.add_node(art_id, **{
                "label": f"Art. {art_num}.º",
                "node_type": "article",
                "doc_type": doc_type,
                "color": DOC_TYPE_COLORS.get(doc_type, DOC_TYPE_COLORS["unknown"]),
                "size": 10,
                "parent_doc": doc_id,
                "article_title": article.get("title", ""),
                "text_preview": article.get("text", "")[:200],
            })

            # Edge from document to its articles
            G.add_edge(doc_id, art_id, edge_type="contains", color="#CCCCCC", width=0.5)

    # ─── Extract References ───
    if references is None:
        references = []
        for doc in documents:
            refs = extract_references_from_document(doc)
            references.extend(refs)

    # ─── Add Reference Edges ───
    for ref in references:
        # Support both Reference objects and plain dicts (from LLM extractor)
        if isinstance(ref, dict):
            source_doc = ref.get("source_document", "")
            source_article = ref.get("source_article")
            target_document = ref.get("target_document", "")
            target_article = ref.get("target_article")
            edge_type = ref.get("edge_type", "cita")
            raw_text = ref.get("raw_text", "")

            source_node = f"{source_doc}_art{source_article}" if source_article else source_doc
            if source_node not in G:
                continue

            # Try to match target article node
            target_node = None
            if target_article:
                candidate = f"{target_document}_art{target_article}"
                if candidate in G:
                    target_node = candidate
                else:
                    # Search all article nodes for this number
                    for node_id in G.nodes():
                        if G.nodes[node_id].get("node_type") == "article" and node_id.endswith(f"_art{target_article}"):
                            target_node = node_id
                            break

            if target_node is None:
                # Try document-level match
                if target_document in G:
                    target_node = target_document
                else:
                    # Create external placeholder
                    target_node = f"ext_{target_document}_{target_article or 'doc'}"
                    if target_node not in G:
                        G.add_node(target_node, **{
                            "label": f"{target_document} Art.{target_article or '?'}",
                            "node_type": "external",
                            "doc_type": target_document,
                            "color": "#95A5A6",
                            "size": 8,
                        })

            if source_node != target_node:
                G.add_edge(source_node, target_node, **{
                    "edge_type": edge_type,
                    "color": ACTION_COLORS.get(edge_type, "#3498DB"),
                    "width": 2 if edge_type in ("revoga", "altera") else 1,
                    "ref_type": "llm",
                    "context": raw_text[:100],
                })
        else:
            # Reference object from regex extractor
            source_node = f"{ref.source_doc}_art{ref.source_article}" if ref.source_article else ref.source_doc

            if source_node not in G:
                continue

            target_node = _find_target_node(G, ref)

            if target_node is None:
                target_node = f"ext_{ref.ref_normalized.replace(' ', '_').lower()}"
                if target_node not in G:
                    G.add_node(target_node, **{
                        "label": ref.ref_normalized[:40],
                        "node_type": "external",
                        "doc_type": ref.ref_type,
                        "color": "#95A5A6",
                        "size": 8,
                    })

            if source_node != target_node:
                G.add_edge(source_node, target_node, **{
                    "edge_type": ref.action,
                    "color": ACTION_COLORS.get(ref.action, "#3498DB"),
                    "width": 2 if ref.action in ("revoga", "altera") else 1,
                    "ref_type": ref.ref_type,
                    "context": ref.context[:100] if ref.context else "",
                })

    return G


def _find_target_node(G: nx.DiGraph, ref: Reference) -> Optional[str]:
    """Try to match a reference to an existing node in the graph."""
    # For article references, search article nodes
    if ref.ref_type == "artigo":
        art_num = ref.ref_value.split("-")[0]
        for node_id, data in G.nodes(data=True):
            if data.get("node_type") == "article" and node_id.endswith(f"_art{art_num}"):
                return node_id

    # For document-level references
    ref_lower = ref.ref_normalized.lower()
    for node_id, data in G.nodes(data=True):
        if data.get("node_type") == "document":
            if ref_lower in node_id.lower() or ref_lower in data.get("label", "").lower():
                return node_id

    return None


def compute_metrics(G: nx.DiGraph) -> dict:
    """Compute graph metrics and centrality measures."""
    metrics = {
        "num_nodes": G.number_of_nodes(),
        "num_edges": G.number_of_edges(),
        "num_documents": sum(1 for _, d in G.nodes(data=True) if d.get("node_type") == "document"),
        "num_articles": sum(1 for _, d in G.nodes(data=True) if d.get("node_type") == "article"),
        "num_external": sum(1 for _, d in G.nodes(data=True) if d.get("node_type") == "external"),
        "density": nx.density(G),
    }

    # Centrality metrics (on undirected version for some metrics)
    G_undirected = G.to_undirected()

    if G.number_of_nodes() > 0:
        # Degree centrality
        degree_cent = nx.degree_centrality(G)
        metrics["top_degree"] = sorted(degree_cent.items(), key=lambda x: x[1], reverse=True)[:10]

        # In-degree (most referenced)
        in_degree = dict(G.in_degree())
        metrics["top_referenced"] = sorted(in_degree.items(), key=lambda x: x[1], reverse=True)[:10]

        # Out-degree (most referencing)
        out_degree = dict(G.out_degree())
        metrics["top_referencing"] = sorted(out_degree.items(), key=lambda x: x[1], reverse=True)[:10]

        # Betweenness centrality
        if G.number_of_nodes() < 5000:
            betweenness = nx.betweenness_centrality(G)
            metrics["top_betweenness"] = sorted(betweenness.items(), key=lambda x: x[1], reverse=True)[:10]

        # PageRank
        try:
            pagerank = nx.pagerank(G)
            metrics["top_pagerank"] = sorted(pagerank.items(), key=lambda x: x[1], reverse=True)[:10]
        except Exception:
            pass

    # Communities (Louvain)
    if community_louvain is not None and G_undirected.number_of_nodes() > 0:
        try:
            partition = community_louvain.best_partition(G_undirected)
            metrics["communities"] = partition
            metrics["num_communities"] = len(set(partition.values()))
        except Exception:
            pass

    # Edge type distribution
    edge_types = {}
    for _, _, data in G.edges(data=True):
        et = data.get("edge_type", "unknown")
        edge_types[et] = edge_types.get(et, 0) + 1
    metrics["edge_type_distribution"] = edge_types

    return metrics


def generate_pyvis_html(G: nx.DiGraph, output_path: str = "graph.html",
                        height: str = "700px", width: str = "100%",
                        filter_contains: bool = True) -> str:
    """
    Generate an interactive HTML visualization using Pyvis.

    Args:
        G: The graph to visualize
        output_path: Path to save the HTML file
        height: Height of the visualization
        width: Width of the visualization
        filter_contains: If True, hide 'contains' edges for cleaner view

    Returns:
        Path to the generated HTML file
    """
    try:
        from pyvis.network import Network
    except ImportError:
        raise ImportError("pyvis is required for visualization: pip install pyvis")

    net = Network(height=height, width=width, directed=True, bgcolor="#0a0a0a",
                  font_color="white", select_menu=False, filter_menu=False)

    net.barnes_hut(gravity=-5000, central_gravity=0.3, spring_length=200)

    # Add nodes
    for node_id, data in G.nodes(data=True):
        node_type = data.get("node_type", "unknown")
        if node_type == "article" and filter_contains:
            # Only show articles that have cross-document references
            has_cross_ref = False
            for _, target, edata in G.out_edges(node_id, data=True):
                if edata.get("edge_type") != "contains":
                    has_cross_ref = True
                    break
            for source, _, edata in G.in_edges(node_id, data=True):
                if edata.get("edge_type") != "contains":
                    has_cross_ref = True
                    break
            if not has_cross_ref:
                continue

        label = data.get("label", node_id)
        color = data.get("color", "#95A5A6")
        size = data.get("size", 10)
        title = f"<b>{label}</b><br>Type: {data.get('doc_type', 'N/A')}<br>Node: {node_type}"

        if node_type == "article":
            title += f"<br>Title: {data.get('article_title', '')}"
            title += f"<br>{data.get('text_preview', '')[:150]}..."

        net.add_node(node_id, label=label, color=color, size=size, title=title)

    # Add edges
    for source, target, data in G.edges(data=True):
        if filter_contains and data.get("edge_type") == "contains":
            continue
        if source not in [n["id"] for n in net.nodes] or target not in [n["id"] for n in net.nodes]:
            continue

        color = data.get("color", "#3498DB")
        width = data.get("width", 1)
        edge_type = data.get("edge_type", "cita")
        title = f"Type: {edge_type}<br>{data.get('context', '')[:100]}"

        net.add_edge(source, target, color=color, width=width, title=title)

    # Save
    net.save_graph(output_path)
    return output_path


def save_graph(G: nx.DiGraph, path: str):
    """Save graph to JSON format."""
    data = nx.node_link_data(G)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_graph(path: str) -> nx.DiGraph:
    """Load graph from JSON format."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return nx.node_link_graph(data, directed=True)


if __name__ == "__main__":
    # Demo with synthetic data
    demo_docs = [
        {
            "document_id": "codigo_trabalho",
            "type": "codigo_trabalho",
            "title": "Código do Trabalho",
            "num_articles": 2,
            "articles": [
                {"number": "1", "title": "Fontes específicas",
                 "text": "Nos termos do artigo 12.º do Código Civil, aplicam-se as disposições da Lei n.º 7/2009."},
                {"number": "2", "title": "Âmbito",
                 "text": "O Decreto-Lei n.º 47344/1966 estabelece disposições conforme a Constituição da República Portuguesa."},
            ],
        },
        {
            "document_id": "codigo_civil",
            "type": "codigo_civil",
            "title": "Código Civil",
            "num_articles": 1,
            "articles": [
                {"number": "12", "title": "Aplicação da lei no tempo",
                 "text": "A lei dispõe para o futuro, nos termos do artigo 1.º do Código do Trabalho."},
            ],
        },
    ]

    G = build_graph(demo_docs)
    metrics = compute_metrics(G)

    print(f"Graph: {metrics['num_nodes']} nodes, {metrics['num_edges']} edges")
    print(f"Documents: {metrics['num_documents']}, Articles: {metrics['num_articles']}")
    print(f"External refs: {metrics['num_external']}")
    print(f"Edge types: {metrics['edge_type_distribution']}")

    print("\nTop referenced nodes:")
    for node, count in metrics.get("top_referenced", [])[:5]:
        print(f"  {node}: {count} incoming refs")
