"""
RAG Agent Module
Retrieval-Augmented Generation agent for querying Portuguese legal documents
with graph-enhanced context.
"""

import os
from typing import Optional

import networkx as nx

try:
    import chromadb
    from chromadb.config import Settings
except ImportError:
    chromadb = None

try:
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain_community.vectorstores import Chroma
    from langchain_community.embeddings import HuggingFaceEmbeddings
    from langchain.chains import ConversationalRetrievalChain
    from langchain.memory import ConversationBufferWindowMemory
    from langchain.prompts import PromptTemplate
    from langchain.embeddings.base import Embeddings
    HAS_LANGCHAIN = True
except ImportError:
    HAS_LANGCHAIN = False

try:
    from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenAIEmbeddings
    HAS_GEMINI = True
except ImportError:
    HAS_GEMINI = False


SYSTEM_PROMPT = """You are a highly specialized legal AI assistant for Portuguese Law.
You have access to a connected network of legal documents (including the Labour Code / Código do Trabalho, Civil Code / Código Civil, and associated amendments).

Answer the user's question accurately in the language they write in (Portuguese or English).

When answering:
1. ALWAYS cite the specific articles and laws that support your answer.
2. Explain the relationships, citations, or amendments between documents if relevant.
3. Be clear but technically precise.
4. Highlight if an article has been marked as revoked (revogado) or amended (alterado).
5. If the context does not contain the answer, state that clearly.

Legal Graph Context (Relationships between documents):
{graph_context}

Relevant Document Text Context:
{context}
"""

QA_PROMPT = PromptTemplate(
    template=SYSTEM_PROMPT + "\n\nQuestion: {question}\n\nAnswer:",
    input_variables=["graph_context", "context", "question"],
) if HAS_LANGCHAIN else None


class LawRAGAgent:
    """RAG Agent with graph-enhanced retrieval for Portuguese legal documents."""

    def __init__(
        self,
        documents: list,
        graph: Optional[nx.DiGraph] = None,
        model_name: str = "gemini-2.0-flash",
        embedding_model: str = "all-MiniLM-L6-v2",
        persist_dir: str = "./data/vectorstore",
        google_api_key: Optional[str] = None,
    ):
        """
        Initialize the RAG agent.

        Args:
            documents: List of parsed document dicts (from pdf_parser)
            graph: Optional NetworkX graph of legal references
            model_name: LLM model name (Google Gemini)
            embedding_model: Sentence-transformer model for embeddings
            persist_dir: Directory to persist the vector store
            google_api_key: Google API key (or set GOOGLE_API_KEY env var)
        """
        if not HAS_LANGCHAIN:
            raise ImportError("LangChain is required: pip install langchain langchain-community langchain-google-genai")

        self.documents = documents
        self.graph = graph
        self.model_name = model_name
        self.persist_dir = persist_dir
        self.api_key = google_api_key or os.getenv("GOOGLE_API_KEY", "")

        # Initialize embeddings (Cloud GoogleGenAI vs Local HuggingFace fallback)
        self.embeddings = None
        if self.api_key and HAS_GEMINI:
            try:
                # Prioritize cloud embeddings for massive speedups (under 3 seconds vs minutes on local CPU)
                emb = GoogleGenAIEmbeddings(
                    model="models/text-embedding-004",
                    google_api_key=self.api_key
                )
                # Quick validation check to confirm API key capability for embeddings
                emb.embed_query("validation")
                self.embeddings = emb
                print("✅ Embeddings configured successfully using Google Cloud (Generative AI)")
            except Exception as e:
                print(f"⚠️ GoogleGenAIEmbeddings failed: {e}. Falling back to local HuggingFace embeddings.")
                
        if not self.embeddings:
            self.embeddings = self._init_local_embeddings(embedding_model)

        # Build vector store
        self.vectorstore = self._build_vectorstore()

        # Initialize LLM and chain
        self.llm = None
        self.chain = None
        self.memory = ConversationBufferWindowMemory(
            memory_key="chat_history",
            return_messages=True,
            output_key="answer",
            k=5,
        )

        if self.api_key and HAS_GEMINI:
            self._init_llm()
        else:
            if not self.api_key:
                print("⚠️ No Google API key found; RAG agent will run in retrieval-only fallback mode.")
            elif not HAS_GEMINI:
                print("⚠️ Gemini integration unavailable. Install langchain_google_genai to enable LLM.")

    def _build_vectorstore(self):
        """Build or load the ChromaDB vector store."""
        chunks = self._prepare_chunks()

        texts = [c["text"] for c in chunks]
        metadatas = [c["metadata"] for c in chunks]

        try:
            vectorstore = Chroma.from_texts(
                texts=texts,
                embedding=self.embeddings,
                metadatas=metadatas,
                persist_directory=self.persist_dir,
            )
            print(f"📚 Vector store built and persisted with {len(texts)} chunks")
        except Exception as e:
            print(f"⚠️ Failed to build persisted Chroma store: {e}. Falling back to in-memory store.")
            vectorstore = Chroma.from_texts(
                texts=texts,
                embedding=self.embeddings,
                metadatas=metadatas,
            )
            print(f"📚 In-memory Vector store built with {len(texts)} chunks")
            
        return vectorstore

    def _init_local_embeddings(self, embedding_model: str):
        """Initialize local HuggingFace embeddings with a fallback using SentenceTransformer."""
        try:
            emb = HuggingFaceEmbeddings(
                model_name=embedding_model,
                model_kwargs={"device": "cpu"},
            )
            print("ℹ️ Using local HuggingFace embeddings (CPU inference)")
            return emb
        except Exception as e:
            print(f"⚠️ HuggingFaceEmbeddings wrapper failed: {e}")
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as ie:
                raise ImportError(
                    "Local embeddings failed because sentence-transformers is not installed. "
                    "Install it with `pip install sentence-transformers`."
                ) from ie

            try:
                model = SentenceTransformer(embedding_model, device="cpu")
                print("ℹ️ Loaded direct SentenceTransformer model as fallback.")
                return SentenceTransformerEmbeddings(model)
            except Exception as e2:
                raise RuntimeError(
                    "Local embedding fallback failed. Verify torch/sentence-transformers compatibility "
                    "or use a valid GOOGLE_API_KEY."
                ) from e2

    def _prepare_chunks(self) -> list:
        """Split documents into chunks for the vector store."""
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            separators=["\n\n", "\n", ". ", " "],
        )

        chunks = []
        for doc in self.documents:
            doc_id = doc["document_id"]
            doc_type = doc.get("type", "unknown")

            for article in doc.get("articles", []):
                art_text = article.get("text", "")
                art_num = article.get("number", "0")
                art_title = article.get("title", "")

                if not art_text.strip():
                    continue

                # Add article header for context
                header = f"[{doc.get('title', doc_id)}] Artigo {art_num}.º - {art_title}\n\n"
                full_text = header + art_text

                splits = splitter.split_text(full_text)
                for i, split in enumerate(splits):
                    chunks.append({
                        "text": split,
                        "metadata": {
                            "document_id": doc_id,
                            "doc_type": doc_type,
                            "article_number": art_num,
                            "article_title": art_title,
                            "chunk_index": i,
                            "source": f"{doc_id}/art{art_num}",
                        },
                    })

        return chunks

    def _init_llm(self):
        """Initialize the LLM and conversational chain with fallbacks."""
        models = [self.model_name, "gemini-2.0-flash", "gemini-flash-latest", "gemini-2.5-flash", "gemini-3.5-flash", "gemini-1.5-flash", "gemini-pro"]
        # Remove duplicates while keeping order
        models = list(dict.fromkeys([m for m in models if m]))
        
        self.llm = None
        for model in models:
            try:
                # Add models/ prefix if needed or standard
                llm = ChatGoogleGenerativeAI(
                    model=model,
                    temperature=0.1,
                    google_api_key=self.api_key,
                )
                # Quick test invoke to confirm API compatibility
                llm.invoke("Hello")
                self.llm = llm
                self.model_name = model
                print(f"✅ RAG LLM initialized successfully with model: {model}")
                break
            except Exception as e:
                print(f"⚠️ RAG LLM failed to init with {model}: {e}")
                
        if not self.llm:
            raise RuntimeError("All LLM models in fallback chain failed to initialize.")

        self.chain = ConversationalRetrievalChain.from_llm(
            llm=self.llm,
            retriever=self.vectorstore.as_retriever(search_kwargs={"k": 6}),
            memory=self.memory,
            return_source_documents=True,
            verbose=False,
        )

    def get_graph_context(self, query: str, top_k: int = 5) -> str:
        """Get relevant graph context for a query based on vector similarity."""
        if self.graph is None:
            return "Grafo legal não disponível."

        # Get similar documents from vectorstore
        similar_docs = self.vectorstore.similarity_search(query, k=top_k)

        # Extract relevant nodes from the graph
        context_parts = []
        seen_nodes = set()

        for doc in similar_docs:
            source = doc.metadata.get("source", "")
            doc_id = doc.metadata.get("document_id", "")

            # Find related nodes in graph
            for node_id in self.graph.nodes():
                if doc_id in node_id and node_id not in seen_nodes:
                    seen_nodes.add(node_id)

                    # Get edges (references)
                    out_edges = list(self.graph.out_edges(node_id, data=True))
                    in_edges = list(self.graph.in_edges(node_id, data=True))

                    if out_edges or in_edges:
                        node_data = self.graph.nodes[node_id]
                        label = node_data.get("label", node_id)
                        context_parts.append(f"\n📌 {label}:")

                        for _, target, edata in out_edges[:3]:
                            target_label = self.graph.nodes[target].get("label", target)
                            edge_type = edata.get("edge_type", "cita")
                            context_parts.append(f"  → {edge_type}: {target_label}")

                        for source_n, _, edata in in_edges[:3]:
                            source_label = self.graph.nodes[source_n].get("label", source_n)
                            edge_type = edata.get("edge_type", "cita")
                            context_parts.append(f"  ← referenced by {source_label} ({edge_type})")

        return "\n".join(context_parts) if context_parts else "No graph relationships found."

    def query(self, question: str) -> dict:
        """
        Query the RAG agent with a natural language question.

        Returns:
            dict with 'answer', 'sources', and 'graph_context'
        """
        # Get graph context
        graph_context = self.get_graph_context(question)

        if self.chain:
            # Use LLM chain
            enhanced_question = (
                f"Contexto do grafo legal:\n{graph_context}\n\n"
                f"Pergunta: {question}"
            )
            result = self.chain({"question": enhanced_question})

            sources = []
            for doc in result.get("source_documents", []):
                sources.append({
                    "source": doc.metadata.get("source", ""),
                    "doc_type": doc.metadata.get("doc_type", ""),
                    "article": doc.metadata.get("article_number", ""),
                    "text_preview": doc.page_content[:200],
                })

            return {
                "answer": result["answer"],
                "sources": sources,
                "graph_context": graph_context,
            }
        else:
            # Fallback: return relevant documents without LLM
            similar_docs = self.vectorstore.similarity_search(question, k=6)

            sources = []
            answer_parts = ["⚠️ LLM not configured. Relevant documents found:\n"]

            for i, doc in enumerate(similar_docs, 1):
                source = doc.metadata.get("source", "unknown")
                answer_parts.append(f"\n**{i}. {source}**\n{doc.page_content[:300]}...\n")
                sources.append({
                    "source": source,
                    "doc_type": doc.metadata.get("doc_type", ""),
                    "article": doc.metadata.get("article_number", ""),
                    "text_preview": doc.page_content[:200],
                })

            return {
                "answer": "\n".join(answer_parts),
                "sources": sources,
                "graph_context": graph_context,
            }

    def search_similar(self, query: str, k: int = 5) -> list:
        """Search for similar document chunks."""
        results = self.vectorstore.similarity_search_with_score(query, k=k)
        return [
            {
                "text": doc.page_content,
                "metadata": doc.metadata,
                "score": float(score),
            }
            for doc, score in results
        ]

    def reset_memory(self):
        """Clear conversation memory."""
        self.memory.clear()


class SentenceTransformerEmbeddings(Embeddings):
    def __init__(self, model):
        self.model = model

    def embed_documents(self, texts):
        vectors = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
        return vectors.tolist()

    def embed_query(self, text):
        vector = self.model.encode([text], convert_to_numpy=True, show_progress_bar=False)[0]
        return vector.tolist()


def create_simple_agent(documents: list, graph=None, api_key=None):
    """Factory function to create a RAG agent with sensible defaults."""
    return LawRAGAgent(
        documents=documents,
        graph=graph,
        google_api_key=api_key,
    )
