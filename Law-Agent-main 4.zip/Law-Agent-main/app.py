"""
Law Agent - Portuguese Legal Network Explorer
Streamlit Frontend Application (English Version)
"""

import os
import sys
import json
import streamlit as st
import networkx as nx
import plotly.graph_objects as go
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from src.reference_extractor import extract_references_from_document, get_reference_summary
from src.graph_builder import build_graph, compute_metrics, generate_pyvis_html, DOC_TYPE_COLORS

# ─── Page Config ───
st.set_page_config(
    page_title="Law Agent - Portuguese Legal Network Explorer",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ───
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

* { font-family: 'Inter', sans-serif; }

.main-header {
    background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
    padding: 2rem; border-radius: 16px; margin-bottom: 2rem;
    border: 1px solid rgba(78, 205, 196, 0.2);
}
.main-header h1 {
    background: linear-gradient(90deg, #4ECDC4, #44B09E);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    font-size: 2.2rem; font-weight: 700; margin: 0;
}
.main-header p { color: #8899AA; font-size: 1rem; margin-top: 0.5rem; }

.metric-card {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    padding: 1.2rem; border-radius: 12px; text-align: center;
    border: 1px solid rgba(78, 205, 196, 0.15);
    transition: transform 0.2s, border-color 0.2s;
}
.metric-card:hover {
    transform: translateY(-2px);
    border-color: rgba(78, 205, 196, 0.4);
}
.metric-card .value {
    font-size: 2rem; font-weight: 700;
    background: linear-gradient(90deg, #4ECDC4, #FF6B6B);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.metric-card .label { color: #8899AA; font-size: 0.85rem; margin-top: 0.3rem; }

.chat-msg {
    padding: 1rem 1.2rem; border-radius: 12px; margin: 0.5rem 0;
    animation: fadeIn 0.3s ease-in;
}
.chat-user {
    background: linear-gradient(135deg, #16213e, #1a1a2e);
    border-left: 3px solid #4ECDC4;
}
.chat-agent {
    background: linear-gradient(135deg, #1a1a2e, #0a0a0a);
    border-left: 3px solid #FF6B6B;
}
@keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

.source-chip {
    display: inline-block; padding: 0.25rem 0.6rem; border-radius: 20px;
    font-size: 0.75rem; margin: 0.15rem;
    background: rgba(78, 205, 196, 0.15); color: #4ECDC4;
    border: 1px solid rgba(78, 205, 196, 0.3);
}
.legend-item { display: flex; align-items: center; gap: 0.5rem; margin: 0.3rem 0; font-size: 0.85rem; }
.legend-dot { width: 12px; height: 12px; border-radius: 50%; display: inline-block; }

iframe { border-radius: 12px; }
</style>
""", unsafe_allow_html=True)


# ─── Session State Init ───
def init_state():
    defaults = {
        "documents": [], "graph": None, "metrics": None,
        "agent": None, "chat_history": [], "data_loaded": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()


# ─── Data Loading ───
def load_txt_data(txt_dir: str, max_llm_articles: int = 0):
    """Parse TXT files, extract relationships using LLM, and build the graph."""
    from src.txt_parser import parse_all_txts
    from src.llm_relation_extractor import extract_relations_with_llm

    with st.spinner("📄 Segmenting TXT files by articles..."):
        docs = parse_all_txts(txt_dir)
        st.session_state.documents = docs

    if not docs:
        st.error("❌ No valid .txt law files found or segmented in data/ directory.")
        return

    with st.spinner("🤖 Extracting legal relationships with Gemini LLM + Regex Hybrid Chain..."):
        all_refs = []
        api_key = os.getenv("GOOGLE_API_KEY", "")
        # Process each document
        for doc in docs:
            # We pass the api key to leverage hybrid Gemini processing
            refs = extract_relations_with_llm(doc, google_api_key=api_key, max_llm_articles=max_llm_articles)
            all_refs.extend(refs)

    with st.spinner("🕸️ Assembling relationship network..."):
        G = build_graph(docs, all_refs)
        st.session_state.graph = G
        st.session_state.metrics = compute_metrics(G)

    # Initialize RAG agent
    try:
        from src.rag_agent import LawRAGAgent
        with st.spinner("🤖 Initializing graph-augmented Law Agent..."):
            st.session_state.agent = LawRAGAgent(
                documents=docs, graph=G, google_api_key=api_key,
            )
    except Exception as e:
        st.warning(f"⚠️ RAG Agent started in offline keyword search mode: {e}")

    st.session_state.data_loaded = True
    st.session_state.all_refs = all_refs
    st.success("✅ Law documents successfully processed and semantic graph constructed!")


def load_demo_data():
    """Load mock legal network demo data instantly."""
    demo_docs = [
        {
            "document_id": "codigo_trabalho", "type": "codigo_trabalho",
            "title": "Labour Code (Lei n.º 7/2009)", "num_articles": 5,
            "articles": [
                {"number": "1", "title": "Specific Sources",
                 "text": "The employment contract is subject to legal rules, under the terms of Article 12 of the Civil Code and in accordance with the Portuguese Constitution."},
                {"number": "11", "title": "Definition of Employment Contract",
                 "text": "An employment contract is one by which a person undertakes to perform work. Decree-Lei n.º 47344/1966 applies subsidiarily."},
                {"number": "12", "title": "Presumption of Contract",
                 "text": "The existence of an employment contract is presumed when the characteristics provided for in Lei n.º 63/2013 are verified."},
                {"number": "127", "title": "Employer Powers",
                 "text": "It is the responsibility of the employer to establish the terms, under the terms of Article 762 of the Civil Code."},
                {"number": "394", "title": "Just Cause for Termination",
                 "text": "The worker may resolve the contract, with Article 799 of the Civil Code being applicable to liability."},
            ],
        },
        {
            "document_id": "codigo_civil", "type": "codigo_civil",
            "title": "Civil Code (DL n.º 47344/66)", "num_articles": 5,
            "articles": [
                {"number": "12", "title": "Application in Time",
                 "text": "The law provides for the future. Refers to the provisions of Article 1 of the Labour Code."},
                {"number": "405", "title": "Contractual Freedom",
                 "text": "The parties have the power to freely establish the content of contracts, under the terms of the Constitution of the Portuguese Republic."},
                {"number": "762", "title": "General Performance Principle",
                 "text": "The debtor performs the obligation when fulfilling the service. Applicable according to Article 127 of the Labour Code."},
                {"number": "799", "title": "Presumption of Fault",
                 "text": "It is up to the debtor to prove that the lack of performance is not due to their fault. Relates to Article 394 of the Labour Code."},
                {"number": "1154", "title": "Definition of Service Contract",
                 "text": "Contract of service provision, in accordance with Lei n.º 7/2009, which approves the Labour Code."},
            ],
        },
        {
            "document_id": "lei_63_2013", "type": "lei",
            "title": "Lei n.º 63/2013 - Combating Bogus Self-Employment",
            "num_articles": 2,
            "articles": [
                {"number": "1", "title": "Subject Matter",
                 "text": "This law establishes mechanisms to combat the improper use of service provision contracts under the terms of the Labour Code."},
                {"number": "2", "title": "Recognition Action",
                 "text": "The worker may bring an action for recognition, in accordance with Article 12 of the Labour Code and Article 1154 of the Civil Code."},
            ],
        },
    ]

    all_refs = []
    for doc in demo_docs:
        refs = extract_references_from_document(doc)
        all_refs.extend(refs)

    G = build_graph(demo_docs, all_refs)
    st.session_state.documents = demo_docs
    st.session_state.graph = G
    st.session_state.metrics = compute_metrics(G)
    st.session_state.all_refs = all_refs

    # Try to init RAG agent
    try:
        from src.rag_agent import LawRAGAgent
        api_key = os.getenv("GOOGLE_API_KEY", "")
        st.session_state.agent = LawRAGAgent(
            documents=demo_docs, graph=G, google_api_key=api_key,
        )
    except Exception as e:
        st.warning(f"⚠️ Offline chatbot initiated: {e}")

    st.session_state.data_loaded = True


# ─── Graph Visualization with Plotly ───
def create_plotly_graph(G: nx.DiGraph, filter_contains=True):
    """Create an interactive Plotly graph visualization."""
    if filter_contains:
        edges_to_show = [(u, v, d) for u, v, d in G.edges(data=True) if d.get("edge_type") != "contains"]
        nodes_in_edges = set()
        for u, v, _ in edges_to_show:
            nodes_in_edges.add(u)
            nodes_in_edges.add(v)
        for n, d in G.nodes(data=True):
            if d.get("node_type") == "document":
                nodes_in_edges.add(n)
    else:
        edges_to_show = list(G.edges(data=True))
        nodes_in_edges = set(G.nodes())

    if not nodes_in_edges:
        return go.Figure()

    subG = G.subgraph(nodes_in_edges)
    pos = nx.spring_layout(subG, k=2.0, iterations=50, seed=42)

    edge_traces = []
    for u, v, data in edges_to_show:
        if u not in pos or v not in pos:
            continue
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        color = data.get("color", "#3498DB")
        edge_type = data.get("edge_type", "cita")

        edge_traces.append(go.Scatter(
            x=[x0, x1, None], y=[y0, y1, None],
            mode="lines", line=dict(width=1.5, color=color),
            hoverinfo="text", hovertext=f"{edge_type.upper()}: {u} → {v}",
            showlegend=False,
        ))

    node_groups = {}
    for node in nodes_in_edges:
        if node not in pos:
            continue
        data = G.nodes[node]
        doc_type = data.get("doc_type", "unknown")
        if doc_type not in node_groups:
            node_groups[doc_type] = {"x": [], "y": [], "text": [], "hover": [], "size": []}
        x, y = pos[node]
        node_groups[doc_type]["x"].append(x)
        node_groups[doc_type]["y"].append(y)
        node_groups[doc_type]["text"].append(data.get("label", node)[:25])
        node_groups[doc_type]["size"].append(data.get("size", 10))

        hover = f"<b>{data.get('label', node)}</b><br>Type: {data.get('node_type', 'N/A').title()}"
        if data.get("article_title"):
            hover += f"<br>Title: {data['article_title']}"
        node_groups[doc_type]["hover"].append(hover)

    node_traces = []
    for doc_type, group in node_groups.items():
        color = DOC_TYPE_COLORS.get(doc_type, "#95A5A6")
        node_traces.append(go.Scatter(
            x=group["x"], y=group["y"],
            mode="markers+text", name=doc_type.replace("_", " ").title(),
            marker=dict(size=group["size"], color=color, line=dict(width=1, color="rgba(255,255,255,0.13)")),
            text=group["text"], textposition="top center",
            textfont=dict(size=9, color="#cccccc"),
            hoverinfo="text", hovertext=group["hover"],
        ))

    fig = go.Figure(data=edge_traces + node_traces)
    fig.update_layout(
        plot_bgcolor="#0a0a0a", paper_bgcolor="#0a0a0a",
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        margin=dict(l=0, r=0, t=30, b=0),
        height=550, showlegend=True,
        legend=dict(
            bgcolor="rgba(26,26,46,0.8)", bordercolor="rgba(78,205,196,0.3)",
            borderwidth=1, font=dict(color="#E0E0E0", size=11),
        ),
        hoverlabel=dict(bgcolor="#1a1a2e", font_size=12),
    )
    return fig


# ─── Sidebar ───
with st.sidebar:
    st.markdown("### 🏛️ Law Agent")
    st.markdown("---")

    # Data source
    st.markdown("#### 📂 Data Source Ingestion")
    data_source = st.radio(
        "Ingestion method:",
        ["🌐 DRE Web Scraper", "📄 Load Local TXTs", "🎮 Interactive Demo Data"],
        index=2,
    )

    # LLM extraction controls
    st.markdown("---")
    st.markdown("#### ⚙️ Relationship Extraction Options")
    use_llm = st.checkbox("🤖 Use LLM for Relation Extraction", value=False, help="Uses Gemini LLM to extract relationships. If disabled, uses fast Regex local extraction.")
    max_llm_arts = 0
    if use_llm:
        max_llm_arts = st.slider("Max articles per document to process with LLM:", min_value=1, max_value=30, value=5)

    st.markdown("---")

    if data_source == "🌐 DRE Web Scraper":
        st.caption("Scrapes consolidated laws directly from Diário da República Electronico.")
        scrape_themes = st.multiselect("Themes to query:", ["Trabalho", "Civil"], default=["Trabalho", "Civil"])
        if st.button("🌐 Start Playwright Pipeline", use_container_width=True, type="primary"):
            try:
                from src.scraper import scrape_all
                status_box = st.empty()
                
                # Dynamic Streamlit logs in English
                def update_progress(msg):
                    status_box.text(msg.replace("Tema", "Theme").replace("leis encontradas", "laws found").replace("artigos", "articles").replace("Já existe", "Already exists"))
                    
                with st.spinner("🌐 Crawling DRE OutSystems Portal..."):
                    results = scrape_all(
                        output_dir="data",
                        headless=True,
                        themes=scrape_themes,
                        progress_callback=update_progress
                    )

                total_docs = sum(len(d) for d in results.values())
                total_arts = sum(doc["num_articles"] for docs in results.values() for doc in docs)
                st.success(f"✅ Crawled {total_docs} documents with {total_arts} articles!")

                # Auto-load the scraped data
                load_txt_data("data", max_llm_articles=max_llm_arts)
            except Exception as e:
                st.error(f"❌ Scraping pipeline error: {e}")

    elif data_source == "📄 Load Local TXTs":
        txt_dir = st.text_input("Local directory path:", value="data")
        if st.button("🚀 Process Local Data", use_container_width=True, type="primary"):
            load_txt_data(txt_dir, max_llm_articles=max_llm_arts)

    else:
        if st.button("🎮 Load Demo Data", use_container_width=True, type="primary"):
            load_demo_data()
            st.success("✅ Interactive demo legal network loaded!")

    # API Key
    st.markdown("---")
    st.markdown("#### 🔑 LLM Configuration")
    api_key = st.text_input(
        "Google API Key:",
        type="password",
        value=os.getenv("GOOGLE_API_KEY", ""),
        placeholder="Enter your Google API key for Gemini/GenAI",
    )
    if api_key:
        os.environ["GOOGLE_API_KEY"] = api_key
        if st.session_state.agent and st.session_state.agent.api_key != api_key:
            st.session_state.agent.api_key = api_key
            try:
                st.session_state.agent._init_llm()
            except Exception as e:
                st.error(f"LLM initialization failure: {e}")

    # Metrics
    if st.session_state.metrics:
        st.markdown("---")
        st.markdown("#### 📊 Network Metrics")
        m = st.session_state.metrics
        st.metric("Nodes (Articles + Docs)", m["num_nodes"])
        st.metric("Edges (Citations)", m["num_edges"])
        st.metric("Documents Ingested", m["num_documents"])
        st.metric("Articles Extracted", m["num_articles"])
        st.metric("External Citations", m["num_external"])
        if "num_communities" in m:
            st.metric("Louvain Communities", m["num_communities"])

        # Edge type distribution
        if m.get("edge_type_distribution"):
            st.markdown("**Citation Types:**")
            for etype, count in sorted(m["edge_type_distribution"].items(), key=lambda x: -x[1]):
                if etype != "contains":
                    st.markdown(f"- `{etype.upper()}`: {count}")

    # Legend
    st.markdown("---")
    st.markdown("#### 🎨 Theme Coloring")
    for doc_type, color in DOC_TYPE_COLORS.items():
        name = doc_type.replace("_", " ").title()
        st.markdown(f'<div class="legend-item"><span class="legend-dot" style="background:{color}"></span>{name}</div>', unsafe_allow_html=True)


def _search_documents_fallback(query: str, documents: list) -> str:
    """Keyword search fallback when Gemini is offline."""
    query_lower = query.lower()
    results = []
    for doc in documents:
        for art in doc.get("articles", []):
            text = art.get("text", "").lower()
            title = art.get("title", "").lower()
            if any(word in text or word in title for word in query_lower.split() if len(word) > 3):
                results.append(
                    f"**{doc.get('title', doc['document_id'])} - Art. {art['number']}.º** "
                    f"({art.get('title', '')})\n{art.get('text', '')[:250]}..."
                )
    if results:
        return "📋 **Relevant articles found:**\n\n" + "\n\n---\n\n".join(results[:5])
    return "❌ No relevant articles found. Try rephrasing your question."


# ─── Main Content ───
st.markdown("""
<div class="main-header">
    <h1>🏛️ Law Agent Challenge</h1>
    <p>Semantic Knowledge Graph & Conversational Agent for Portuguese Labour and Civil Codes</p>
</div>
""", unsafe_allow_html=True)

if not st.session_state.data_loaded:
    st.info("👈 Ingest or load data using the sidebar options to begin exploration (choose **Interactive Demo Data** for a quick preview)")
    st.stop()

# ─── Metrics Row ───
docs = st.session_state.documents
G = st.session_state.graph
metrics = st.session_state.metrics

col1, col2, col3, col4, col5 = st.columns(5)
metric_data = [
    (col1, str(metrics["num_documents"]), "📄 Documents"),
    (col2, str(metrics["num_articles"]), "📝 Articles"),
    (col3, str(metrics["num_edges"]), "🔗 Citations"),
    (col4, str(metrics["num_external"]), "🌐 Ext Citations"),
    (col5, f"{metrics['density']:.4f}", "📐 Graph Density"),
]
for col, val, label in metric_data:
    col.markdown(f'<div class="metric-card"><div class="value">{val}</div><div class="label">{label}</div></div>', unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ─── Tabs ───
tab_graph, tab_chat, tab_analysis, tab_docs = st.tabs(["🕸️ Interactive Network", "💬 Conversational AI", "📊 Strategic Insights", "📄 Document Explorer"])

# ─── Graph Tab ───
with tab_graph:
    st.markdown("### Portuguese Legal Reference Network")
    st.write("Nodes represent documents and individual articles. Edges trace citations. Double-click or scroll to zoom.")

    gcol1, gcol2 = st.columns([1, 4])
    with gcol1:
        show_contains = st.checkbox("Show 'contains' parent edges", value=False)
        st.markdown("**Edge Type Action Map:**")
        from src.graph_builder import ACTION_COLORS
        for action, color in ACTION_COLORS.items():
            st.markdown(f'<span style="color:{color}">━━</span> {action.upper()}', unsafe_allow_html=True)

    with gcol2:
        fig = create_plotly_graph(G, filter_contains=not show_contains)
        st.plotly_chart(fig, use_container_width=True)

    # Pyvis HTML interactive iframe
    with st.expander("🔍 Show full-screen interactive Pyvis visualization"):
        try:
            html_path = generate_pyvis_html(G, output_path="data/graph_viz.html", filter_contains=not show_contains)
            with open(html_path, "r", encoding="utf-8") as f:
                html_content = f.read()
            st.components.v1.html(html_content, height=600, scrolling=True)
        except Exception as e:
            st.warning(f"Pyvis rendering not available: {e}")

# ─── Chat Tab ───
with tab_chat:
    st.markdown("### 💬 Conversational Law Agent")
    st.write("Ask natural language questions about the Labour and Civil codes. The agent fetches graph connections alongside text similarity to produce citation-complete answers.")

    # Chat history display
    for msg in st.session_state.chat_history:
        role_class = "chat-user" if msg["role"] == "user" else "chat-agent"
        icon = "👤" if msg["role"] == "user" else "🤖"
        st.markdown(f'<div class="chat-msg {role_class}">{icon} {msg["content"]}</div>', unsafe_allow_html=True)

        if msg.get("sources"):
            chips = " ".join([f'<span class="source-chip">{s["source"]}</span>' for s in msg["sources"][:5]])
            st.markdown(f"📎 Verified Sources: {chips}", unsafe_allow_html=True)

    # Chat input
    question = st.chat_input("Query the legal network (e.g., 'What is just cause for termination?')...")

    if question:
        st.session_state.chat_history.append({"role": "user", "content": question})

        if st.session_state.agent:
            with st.spinner("Analyzing graph and generating response..."):
                result = st.session_state.agent.query(question)
                answer = result["answer"]
                sources = result.get("sources", [])
        else:
            answer = _search_documents_fallback(question, docs)
            sources = []

        st.session_state.chat_history.append({"role": "agent", "content": answer, "sources": sources})
        st.rerun()

    # Example queries
    st.markdown("---")
    st.markdown("**💡 Example Legal Queries:**")
    examples = [
        "What articles of the Civil Code are referenced by the Labour Code?",
        "What does Article 394 of Labour Code say about just cause?",
        "What is the relationship between Article 12 of the Civil Code and the Labour Code?",
        "Which articles have been revoked or amended?",
    ]
    ecols = st.columns(2)
    for i, ex in enumerate(examples):
        if ecols[i % 2].button(f"💡 {ex[:70]}...", key=f"ex_{i}", use_container_width=True):
            st.session_state.chat_history.append({"role": "user", "content": ex})
            st.rerun()

# ─── Analysis Tab ───
with tab_analysis:
    st.markdown("### 📊 Network & Regulatory Insights")
    st.write("Calculations are evaluated using graph theory algorithms to extract the most crucial points of the legal network.")

    # High-impact alert panel: Revocation & Amendment analysis
    st.markdown("#### ⚠️ Regulatory Action Alerts")
    revocation_edges = []
    amendment_edges = []
    
    for u, v, d in G.edges(data=True):
        etype = d.get("edge_type", "")
        if etype == "revoga":
            revocation_edges.append((u, v, d.get("context", "")))
        elif etype == "altera":
            amendment_edges.append((u, v, d.get("context", "")))

    if revocation_edges or amendment_edges:
        rac1, rac2 = st.columns(2)
        with rac1:
            st.error(f"🔴 **Revocation Alerts ({len(revocation_edges)} detected)**")
            for src, tgt, ctx in revocation_edges[:10]:
                st.markdown(f"**{src.replace('_', ' ').title()}** revokes **{tgt.replace('_', ' ').title()}**")
                if ctx:
                    st.caption(f"Context: *{ctx}*")
        with rac2:
            st.warning(f"🟡 **Amendment Alerts ({len(amendment_edges)} detected)**")
            for src, tgt, ctx in amendment_edges[:10]:
                st.markdown(f"**{src.replace('_', ' ').title()}** amends **{tgt.replace('_', ' ').title()}**")
                if ctx:
                    st.caption(f"Context: *{ctx}*")
    else:
        st.info("No active revocations or amendments detected in the loaded dataset.")

    st.markdown("---")

    acol1, acol2 = st.columns(2)

    with acol1:
        st.markdown("#### 🏆 Most Cited / Central Articles (In-Degree)")
        # In-degree measures direct citation incoming count
        in_degrees = dict(G.in_degree())
        # Filter for article nodes only
        article_in_degrees = {k: v for k, v in in_degrees.items() if G.nodes[k].get("node_type") == "article"}
        sorted_in = sorted(article_in_degrees.items(), key=lambda x: -x[1])[:10]
        
        for node, count in sorted_in:
            if count > 0:
                node_label = G.nodes[node].get("label", node) if node in G else node
                parent = G.nodes[node].get("parent_doc", "").replace("_", " ").title()
                st.markdown(f"**{node_label}** ({parent}) — **{count}** incoming references")

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("#### 🔗 High Brokerage Articles (Betweenness)")
        # Betweenness centrality identifies gatekeeper nodes bridging clusters
        if metrics.get("top_betweenness"):
            for node, score in metrics["top_betweenness"][:5]:
                if score > 0:
                    node_label = G.nodes[node].get("label", node) if node in G else node
                    st.markdown(f"**{node_label}** — score: {score:.4f}")

    with acol2:
        st.markdown("#### 📈 Network Prestige (PageRank)")
        if metrics.get("top_pagerank"):
            for node, score in metrics["top_pagerank"][:10]:
                node_label = G.nodes[node].get("label", node) if node in G else node
                st.progress(min(score * 25, 1.0), text=f"{node_label}: {score:.4f}")

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("#### 📤 Most Out-Referencing Articles (Out-Degree)")
        out_degrees = dict(G.out_degree())
        article_out_degrees = {k: v for k, v in out_degrees.items() if G.nodes[k].get("node_type") == "article"}
        sorted_out = sorted(article_out_degrees.items(), key=lambda x: -x[1])[:5]
        
        for node, count in sorted_out:
            if count > 0:
                node_label = G.nodes[node].get("label", node) if node in G else node
                st.markdown(f"**{node_label}** — **{count}** citations out")

    # Edge distribution chart
    st.markdown("---")
    st.markdown("#### Citation Action Distribution Map")
    if metrics.get("edge_type_distribution"):
        dist = {k: v for k, v in metrics["edge_type_distribution"].items() if k != "contains"}
        if dist:
            fig_bar = go.Figure(data=[go.Bar(
                x=[k.upper() for k in dist.keys()], y=list(dist.values()),
                marker_color=[ACTION_COLORS.get(k, "#3498DB") for k in dist.keys()],
            )])
            fig_bar.update_layout(
                plot_bgcolor="#0a0a0a", paper_bgcolor="#0a0a0a",
                font=dict(color="#E0E0E0"), height=350,
                margin=dict(l=40, r=20, t=20, b=40),
            )
            st.plotly_chart(fig_bar, use_container_width=True)

# ─── Documents Tab ───
with tab_docs:
    st.markdown("### 📄 Segmented Document Repository")
    st.write("Browse the exact text chunks indexed by the vector search and semantic parser.")

    for doc in docs:
        with st.expander(f"📜 {doc.get('title', doc['document_id'])} ({doc['num_articles']} articles)"):
            st.markdown(f"**Document ID:** `{doc['document_id']}`")
            st.markdown(f"**Type:** `{doc.get('type', 'unknown').upper()}`")
            st.markdown("---")

            for art in doc.get("articles", [])[:25]:
                st.markdown(f"**Article {art['number']}.º** — {art.get('title', '')}")
                st.text(art.get("text", "")[:350] + ("..." if len(art.get("text", "")) > 350 else ""))
                st.markdown("---")
