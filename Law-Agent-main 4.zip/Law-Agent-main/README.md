# Law Agent

Portuguese legal network explorer with retrieval-augmented generation and graph-enhanced legal reasoning.

The project parses Portuguese law texts, extracts citations and references, builds a NetworkX graph of legal relationships, and provides a conversational RAG agent for querying the dataset.

## Features

- Extracts articles, legal references, and document relationships from TXT files.
- Builds a graph of citations and amendments between laws and articles.
- Uses ChromaDB vector store for semantic search over legal text.
- Supports Google Gemini / Generative AI via `langchain_google_genai` for conversational answers.
- Fallback retrieval-only mode when the LLM is not configured.
- Streamlit UI with graph visualization, chat interface, metrics, and document explorer.

## Repository Structure

- `app.py` - Streamlit frontend and main application flow.
- `requirements.txt` - Python dependencies.
- `src/`
  - `rag_agent.py` - RAG agent implementation with Chroma and optional Gemini.
  - `llm_relation_extractor.py` - Hybrid LLM/regex extraction of legal references.
  - `graph_builder.py` - Builds the legal network graph and computes metrics.
  - `reference_extractor.py` - Reference extraction helpers.
  - `txt_parser.py` - Parses `.txt` legal text files into articles.
  - `scraper.py` - Optional scraper for remote Diário da República data.
- `data/` - Document data, vectorstore persistence, and generated graph HTML.

## Prerequisites

- Python 3.9+
- `pip`
- macOS / Linux / Windows shell

## Installation

```bash
cd /Users/diogovenancio/Downloads/Law-Agent-main
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

If you want Gemini / Google Generative AI support for the chat assistant, also install:

```bash
pip install langchain-google-genai
```

## Running the App

Start the Streamlit UI with:

```bash
python3 -m streamlit run app.py
```

If the `streamlit` CLI is not on your PATH, use the `python3 -m streamlit` form.

## Configuring the LLM

The app supports Google Gemini via `langchain_google_genai`.

1. Set your Google API key in the environment:

```bash
export GOOGLE_API_KEY="YOUR_GOOGLE_API_KEY"
```

2. Or paste it into the `Google API Key:` field in the Streamlit sidebar.

3. If the key is valid and `langchain_google_genai` is installed, the chat agent will initialize the LLM.

### Notes

- If the LLM is not configured or fails to initialize, the app falls back to retrieval-only results and shows a message like:
  - `⚠️ LLM not configured. Relevant documents found`
- The field in the UI now starts empty to avoid using a placeholder fake key.

## Usage

- Use `Load Demo Data` for a quick preview without external files.
- Use `Load Local TXTs` to process TXT law files from a local directory.
- Use `DRE Web Scraper` to crawl and ingest consolidated laws from the Diário da República portal.
- Ask natural language legal questions in the `Conversational AI` tab.
- Explore the network graph and document sources.

## Data and Vector Store

- Text documents are split into article chunks before vectorization.
- Chroma stores text chunks in `data/vectorstore/`.
- The RAG agent uses semantic search plus graph context to find relevant legal citations.

## Troubleshooting

- `zsh: command not found: streamlit`
  - Run with `python3 -m streamlit run app.py`.
- `LLM initialization failure`
  - Check that `GOOGLE_API_KEY` is set and valid.
  - Ensure `langchain_google_genai` is installed.
- If chat still returns retrieval-only answers, the agent is running in fallback mode because the LLM layer did not start.

## Important Notes

- The project is designed for Portuguese law documents and legal reference extraction.
- It is not a substitute for real legal advice.
- Always verify citations and legal interpretation with qualified professionals.
